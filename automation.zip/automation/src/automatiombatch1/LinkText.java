package automatiombatch1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinkText {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Data\\Monika\\chromedriver.exe");
        WebDriver driver=new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        
        // for login
     driver.findElement(By.name("username")).sendKeys("Admin");
    driver.findElement(By.name("password")).sendKeys("admin123");
    
   // for forgot password
    driver.findElement(By.cssSelector("p[class='oxd-text oxd-text--p orangehrm-login-forgot-header']")).click();
  driver.findElement(By.name("username")).sendKeys("Admin");
  driver.findElement(By.cssSelector("button[type='button']")).click();
  
  
  //  driver.findElement(By.xpath("//div[class='oxd-autocomplete-text-input--before']")).sendKeys("monika");
    
    
    
    
    
    
    
   // driver.findElement(By.tagName("button")).click();
    //driver.findElement(By.cssSelector("a[href='/web/index.php/pim/viewPimModule']")).click();
   // driver.findElement(By.xpath("//img[@class='oxd-userdropdown-img']")).click();
    //driver.findElement(By.partialLinkText("Logout")).click();

   // driver.findElement(By.linkText("Haben Sie ihr Passwort vergessen? ")).click();
    
    

	}

}

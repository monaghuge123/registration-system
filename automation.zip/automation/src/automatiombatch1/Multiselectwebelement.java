package automatiombatch1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Multiselectwebelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Data\\Monika\\chromedriver.exe");
        WebDriver driver=new ChromeDriver();
        
        // To open the application
       driver.get("https://www.naukri.com/mnjuser/homepage");
       
       //to identify how many text box is available on that page by tagname
      List<WebElement> textbox= driver.findElements(By.tagName("input"));
      
      //To print total no of textbox
       System.out.println("no of textbox  "+textbox.size());             //if size is not found then return zero
       
      //to print out that textbox                                         
      System.out.println(textbox);
      
      //to found out monika 
     // List<WebElement>link=driver.findElements(By.tagName("monika"));
     // System.out.println(link);                                                                             //it show empty list  
      //System.out.println(link.size());                                           // it show zero means return type of integer  because no element found of these tagname
      
      
      //To identify which text box have text and which have attribute
      for (WebElement i:textbox)
      {
      System.out.println(i.getText());
      
      System.out.println(i.getAttribute("href"));
      
	 }
      
      
      
      //find elements return list of webelement
      //find element dont throw exception
      //if element not found then it return empty list 
      // if the no of element is not found means size is not found then he return zero
      //if text and attribute is not given then the retun type of string is print i.e null
      
      
      
      

}}

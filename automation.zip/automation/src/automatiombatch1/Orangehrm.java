package automatiombatch1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Orangehrm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Data\\Monika\\chromedriver.exe");
        WebDriver driver=new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        
        //for login
     driver.findElement(By.name("username")).sendKeys("Admin");
    driver.findElement(By.name("password")).sendKeys("admin123");
    driver.findElement(By.tagName("button")).click();
    
     //for pim module
   // driver.findElement(By.cssSelector("a[href='/web/index.php/pim/viewPimModule']")).click();
    //driver.findElement(By.xpath("div.oxd-autocomplete-text-input--before")).sendKeys("monika");
    
    
    
   // for logout
    driver.findElement(By.cssSelector("i[class='oxd-icon bi-caret-down-fill oxd-userdropdown-icon']")).click();
    driver.findElement(By.cssSelector("a[href='/web/index.php/auth/logout']")).click();
  
    
    
    
    // driver.findElement(By.xpath("//img[@class='oxd-userdropdown-img']")).click();
     //driver.findElement(By.xpath("//div[class='oxd-autocomplete-text-input--before']")).sendKeys("monika");
     
     
    
//	}}
        
//        
    
    
    
    
    // To open the application

 //       driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
//      driver.findElement(By.xpath("//input[@name='username']")).sendKeys("Admin");
//      driver.findElement(By.xpath("//input[@name='password']")).sendKeys("admin123");
//      driver.findElement(By.tagName("button")).click();
//      driver.findElement(By.xpath("//img[@class='oxd-userdropdown-img']")).click();
//      driver.findElement(By.linkText("Logout")).click();
	}}
////
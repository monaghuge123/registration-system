package automatiombatch1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Naukri {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     System.setProperty("webdeiver.chrome.driver", "\"C:\\Data\\Monika\\chromedriver.exe\"");
     WebDriver driver = new ChromeDriver();
     driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
  
     
	}

}

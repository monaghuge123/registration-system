package automatiombatch1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Bootstrapgoigibo {
	
	
	public static void main(String[] args) {
		// TODO launch the browser
		System.setProperty("webdriver.chrome.driver", "C:\\Data\\Monika\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//to open application
		driver.get("https://www.goibibo.com/");
		//to identify dropdown
		driver.findElement(By.xpath("(//p[text()='Enter city or airport'])[1]")).click();
		//to pass the value in dropdown.
	    driver.findElement(By.xpath("//input[@type='text']")).sendKeys("p");
	    
	    //to identify list of value
	    List<WebElement> list =driver.findElements(By.xpath("//ul[@id='autoSuggest-list']//li[@role='presentation']//div//p[@class='sc-bBHHxi jaZCwD']//span[@class='autoCompleteTitle ']"));
	    //no of value present in dropdown
	    System.out.println("List is "+list.size());
	    
	    //to fetch text of that value and select one option
	    for(WebElement i:list)
	    {
	    	String place=i.getText();
	    	System.out.println(place);
	    	if(place.contains("Pune, India "))
	    	{
	    		i.click();
	    		break;
	    	}
	    }
	    
	    
	  //  driver.findElement(By.xpath("(//p[text()='Enter city or airport'])[2]")).click();   this step is not required because he automatically click on that dropdown
	    driver.findElement(By.xpath("//input[@type='text']")).sendKeys("K");
	    List <WebElement>list2=driver.findElements(By.xpath("//ul[@id='autoSuggest-list']//li//div//p//span[@class='autoCompleteTitle ']"));
	    System.out.println("List is "+list2.size());
	    for(WebElement i:list2)
	    {
	    	String place=i.getText();
	    	System.out.println(place);
	    	if(place.contains("Kanpur, India"))
	    	{
	    		i.click();
	    		break;
	    	}
	    }   
	    
	   // driver.findElement(By.xpath("(//div[@role='heading'])[2]")).click();
	    //code for clicking on 30 date
	    driver.findElement(By.xpath("(//div[@role='gridcell']//p[text()='30'])[2]")).click();
	    //code for going to next month button
	    driver.findElement(By.xpath("//span[@role='button'and @aria-label='Next Month']")).click();
	    //it is use for select next month29 date
	    driver.findElement(By.xpath("(//p[text()='29'])[2]")).click();
}}

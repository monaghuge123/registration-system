package automatiombatch1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locators {
	public static void main(String[] args) {
		// TO launch the browser
		System.setProperty("webdriver.chrome.driver","C:\\Data\\Monika\\chromedriver.exe\\");
        WebDriver driver=new ChromeDriver();
        
        // To open the application
       driver.get("http://orangehrm.qedgetech.com/symfony/web/index.php/auth/login");
       
       //identify username by id
       driver.findElement(By.id("txtUsername")).sendKeys("Admin");
       
       //identify password by name
       driver.findElement(By.name("txtPassword")).sendKeys("admin123");
      //driver.findElement(By.className("button")).click();
       
       // links are generally identify  by these two method
       //find link by partial link Text
      // driver.findElement(By.partialLinkText("password?")).click();
      
       //find element by link Text
       // driver.findElement(By.linkText("Forgot your password?")).click();
       
      
	}

}

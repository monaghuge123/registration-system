package automatiombatch1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Bootstrapdropdown {

	public static void main(String[] args) throws InterruptedException {
		// TO launch the browser
		System.setProperty("webdriver.chrome.driver", "C:\\Data\\Monika\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//To open application
		driver.get("https://www.w3schools.com/bootstrap/bootstrap_dropdowns.asp");
		//to identify dropdown
		driver.findElement(By.id("menu1")).click();
		Thread.sleep(10);
		//to identify value from that dropdown
		List<WebElement> list=driver.findElements(By.xpath("//ul[@class='dropdown-menu test']"));
		//to fetch no of value available in dropdown
		System.out.println("list of value is "+list.size());
		
		//to fetch text of each value and select one value from them
		for(WebElement i:list) 
		{
			String text=i.getText();
			System.out.println(text);
			if(text.contains("HTML"))
			{
				i.click();
				break;
			}
		}
	}

}

package automatiombatch1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Google {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Data\\Monika\\selenium-server-4.4\\chromedriver.exe\\");
          WebDriver driver=new ChromeDriver();
         driver.get("https://www.google.com/");
         //webdriver command for title in single line
          System.out.println("the title is"+driver.getTitle());
        //webdriver command for current url in single line
         System.out.println("current url is "+driver.getCurrentUrl()); 
        //webdriver command for page source with validation
         String pages=driver.getPageSource();
         System.out.println(pages);
         
         
        //  driver.close();
	}

}

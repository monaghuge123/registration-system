package automatiombatch1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectmethodDropdown {
	
	public static void getdropdowngeneric(WebElement ele,String value) {      //ek staic method ghetli ani weblement ele ani String value ghetli
		 Select alloption =new Select(ele);                                   //ithe Ele put kel
		  List<WebElement> dpoption= alloption.getOptions();
		  System.out.println("no of all  is available "+dpoption.size());
		  for(WebElement i:dpoption) 
		  { 
			  String option=i.getText();
		      System.out.println(option); 
		     if(option.contains(value))                                        //ithe value put keli
		     { 
			   i.click();
			   break; 
			  }
		  
		  }
		 
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Data\\Monika\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		// for name last name ,no , password.
		driver.findElement(By.xpath("//a[text()='Create New Account']")).click();
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Moinka");
		driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Throve");
		driver.findElement(By.xpath("//input[@name='reg_email__']")).sendKeys("9823525182");
		driver.findElement(By.xpath("//input[@id='password_step_input']")).sendKeys("mona123");
		
		WebElement dayele=driver.findElement(By.id("day"));              //ithe single dropdown identify kela
		getdropdowngeneric(dayele,"14");                                 //ani ithe static method cha value taklya
		
		WebElement monthele=driver.findElement(By.id("month"));
		getdropdowngeneric(monthele,"May");
		
		WebElement yearele=driver.findElement(By.id("year"));
		getdropdowngeneric(yearele,"1997");
		
		
		
		
		

////		 dropdown automation-------all select command for single value selection
//		 Select daydd =new Select(driver.findElement(By.name("birthday_day")));
//		 daydd.selectByVisibleText("10");
//		 daydd.selectByValue("10");
//		 daydd.selectByIndex(5);
//
////		 if we want to select all the value from day dropdown then
//		 
//		 List<WebElement> alloptions=daydd.getOptions();
//		 System.out.println("list of all option is "+alloptions.size());
//		 for(WebElement i:alloptions)         // all value cha text fetch karaycha manun alloption ghene
//		 {
//		 String option=i.getText();
//		 System.out.println(option);
//		 if(option.contains("7"))           //-----jar text madhe 7 text jala available aajhe tefetch karav lagte manun option ghetl
//		 {
//		 i.click();
//		 break;
//		 }
//		 }
//
//	
////           dropdown for month
//		  
//		  Select mthdd=new Select(driver.findElement(By.name("birthday_month")));  // ithe single element find kela
//		  List<WebElement> monthoption= mthdd.getOptions();                        // tya  single element madhil value identify kelya
//		  System.out.println("no of all month is available "+monthoption.size());   // tya kiti value aahet tya identify kelya
//		  for(WebElement i:monthoption)                                             //pratek value select keli
//		  {                                                    
//			  String month=i.getText();                                              //tya value cha text fetch kel
//		      System.out.println(month); 
//		     if(month.contains("May"))                                               //fetch kelelya text paiki ek value select keli
//		     { 
//			   i.click();
//			   break; 
//			  }
//		  
//		  }
//		 

	}

}
